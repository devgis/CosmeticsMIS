﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace 化妆品信息管理系统
{
    /// <summary>
    /// MainWindowworker.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindowworker : Window
    {
        public MainWindowworker()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            编辑化妆品信息  cosmetics = new 编辑化妆品信息 ();
            cosmetics.Show();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            编辑用户信息 users = new 编辑用户信息();
            users.Show();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            审核用户评论 review = new 审核用户评论();
            review.Show();
        }
    }
}
