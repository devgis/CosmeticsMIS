﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace 化妆品信息管理系统
{
    /// <summary>
    /// 海蓝之谜修护唇霜.xaml 的交互逻辑
    /// </summary>
    public partial class 海蓝之谜修护唇霜 : Window
    {
        public 海蓝之谜修护唇霜()
        {
            InitializeComponent();
        }
    }
}
